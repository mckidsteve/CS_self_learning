package editor;

public class Editor {
    
    // ...
    
    /**
     * Modifies `buf` by replacing the first occurrence of `pattern` with `replacement`.
     * If `pattern` is not found in `buf`, then has no effect.
     * @param buf buffer to modify
     * @param pattern text to find
     * @param replacement replacement text
     * @return true if and only if a replacement was made
     */
    public static boolean findReplace(EditBuffer buf, String pattern, String replacement) {
        int i = buf.toString().indexOf(pattern);
        if (i == -1) {
            return false;
        }
        buf.delete(i, pattern.length());
        buf.insert(i, replacement);
        return true;
    }
    
    // ...
}
