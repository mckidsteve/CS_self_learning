package editor;

/**
 * An EditBuffer represents a threadsafe mutable string of characters in a text editor.
 */
public interface EditBuffer {

    /**
     * Modifies this by inserting a string.
     * @param position position to insert at (requires 0 <= position <= current buffer length)
     * @param insertion string to insert
     */
    public void insert(int position, String insertion);
    
    /**
     * Modifies this by deleting a substring
     * @param position start of substring to delete (requires 0 <= position <= current buffer length)
     * @param len length of substring to delete (requires 0 <= len <= current buffer length - position)
     */
    public void delete(int position, int len);
    
    /**
     * @return length of text sequence in this edit buffer
     */
    public int length();
    
    /**
     * @return content of this edit buffer
     */
    @Override public String toString();
}
